package PreperationpartA.Class;

public class luasSegitiga {
    public static void luas(){
        // input
        float alas = 20;
        float tinggi = 25;
        // kode disini
        System.out.println("Menghitung luas segitiga dengan alas "+alas+" dan tinggi "+tinggi);
        System.out.println(0.5*alas*tinggi);
        System.out.println("");
    }
}
